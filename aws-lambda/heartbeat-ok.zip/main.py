"""Dummy heartbeat endpoint."""


def main(event, context):
    """Lambda handler."""
    return "ok"
